
using System;
using Server.Items;
using Server.Mobiles;

namespace Server.Items
{
	
	public class HolyRobe : Robe
	{

		[Constructable]
		public HolyRobe()
		{
            ItemID = 9860;
			Weight = 10.0;
            Name = "A Holy Robe";
            Hue = 1153;
            LootType = LootType.Blessed;
		
		Attributes.BonusStr = 150;
		Attributes.BonusDex = 100;
		Attributes.BonusInt = 100;
		Attributes.AttackChance = 99;
		Attributes.BonusHits = 300;
		Attributes.CastRecovery = 150;
		Attributes.CastSpeed = 150;
		Attributes.DefendChance = 60;
		Attributes.Luck = 100;
		Attributes.ReflectPhysical = 150;

		}

        public HolyRobe(Serial serial): base(serial)
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}
		
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		public override void OnDoubleClick( Mobile from )
		{
            Item y = from.Backpack.FindItemByType(typeof(HolyRobe));
			if ( y !=null )
			{

                if (this.ItemID == 9860) this.ItemID = 7939;
                else if (this.ItemID == 7939) this.ItemID = 9860;

			}
			else
			{ 
                               	from.SendMessage( "You must have the item in your pack to take down the hood it." ); 
                        }
		}
	}
}