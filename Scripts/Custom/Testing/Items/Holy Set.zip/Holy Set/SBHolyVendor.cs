
using System;
using System.Collections;
using Server.Items;

namespace Server.Mobiles
{
	public class SBHolyVendor : SBInfo
	{
		private ArrayList m_BuyInfo = new InternalBuyInfo();
		private IShopSellInfo m_SellInfo = new InternalSellInfo();

		public SBHolyVendor()
		{
		}

		public override IShopSellInfo SellInfo { get { return m_SellInfo; } }
		public override ArrayList BuyInfo { get { return m_BuyInfo; } }

		public class InternalBuyInfo : ArrayList
		{
			public InternalBuyInfo()
			{
				Add( new AnimalBuyInfo( 1, typeof( Eagle ), 402, 10, 5, 0 ) );
				Add( new AnimalBuyInfo( 1, typeof( ScoobyDoo ), 1200, 10, 217, 0 ) );
				Add( new AnimalBuyInfo( 1, typeof( HeavenlyHound ), 2000, 10, 217, 0 ) );
				Add( new AnimalBuyInfo( 1, typeof( HeavenlyDragon ), 1000000, 10, 12, 0 ) );
				Add( new AnimalBuyInfo( 1, typeof( HeavenlySteed ), 25000, 10, 204, 0 ) );
				Add( new AnimalBuyInfo( 1, typeof( HolyWisp ), 5000, 10, 58, 0 ) );				
				Add( new GenericBuyInfo( typeof( HolyBlade ), 75000, 20, 0x13F6, 0 ) );
				Add( new GenericBuyInfo( typeof( HolyStaff ), 99000, 20, 0x13F6, 0 ) );
				Add( new GenericBuyInfo( typeof( HolyCrossbow ), 2100000, 20, 0x13F6, 0 ) );
				Add( new GenericBuyInfo( typeof( HolyShield ), 75000, 20, 0x13F6, 0 ) );
				Add( new GenericBuyInfo( typeof( HolyRobe ), 1000000, 20, 0x13F6, 0 ) );
				
																
		
			}
		}

		public class InternalSellInfo : GenericSellInfo
		{
			public InternalSellInfo()
			{
			}
		}
	}
}
