using System;
using Server;

namespace Server.Items
{
	public class HolyBlade : Katana
	{
		public override int ArtifactRarity{ get{ return 666; } }

		public override int InitMinHits{ get{ return 666; } }
		public override int InitMaxHits{ get{ return 666; } }

		[Constructable]
		public HolyBlade()
		{
			Hue = 1153;
			WeaponAttributes.HitLeechHits = 75;
			WeaponAttributes.HitLeechMana = 75;
			WeaponAttributes.HitLeechStam = 75;
			WeaponAttributes.HitLightning = 175;
			WeaponAttributes.SelfRepair = 10;
			WeaponAttributes.UseBestSkill = 1;
			
			Attributes.CastSpeed = 20;
			Attributes.CastRecovery = 20;
			Attributes.WeaponSpeed = 100;
			Attributes.WeaponDamage = 250;
		}

		public HolyBlade( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}
		
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}