using System;
using Server.Network;
using Server.Items;

namespace Server.Items
{
	[FlipableAttribute( 0xDF1, 0xDF0 )]
	public class HolyStaff : BaseStaff
	{
		public override WeaponAbility PrimaryAbility{ get{ return WeaponAbility.WhirlwindAttack; } }
		public override WeaponAbility SecondaryAbility{ get{ return WeaponAbility.ParalyzingBlow; } }

		public override int AosStrengthReq{ get{ return 30; } }
		public override int AosMinDamage{ get{ return 150; } }
		public override int AosMaxDamage{ get{ return 180; } }
		public override int AosSpeed{ get{ return 400; } }

		public override int OldStrengthReq{ get{ return 30; } }
		public override int OldMinDamage{ get{ return 50; } }
		public override int OldMaxDamage{ get{ return 80; } }
		public override int OldSpeed{ get{ return 330; } }

		public override int InitMinHits{ get{ return 350; } }
		public override int InitMaxHits{ get{ return 750; } }

		[Constructable]
		public HolyStaff() : base( 0xDF1 )
		{
			Name = "Holy Staff";
			Hue = 1153;
			Weight = 0.0;
		
		switch ( Utility.Random( 3 ) )
			{
				case 0: WeaponAttributes.HitHarm = 2500; break;
				case 1: WeaponAttributes.HitHarm = 3500; break;
				case 2: WeaponAttributes.HitHarm = 4500; break;
			}
		switch ( Utility.Random( 3 ) )
			{
				case 0: Attributes.WeaponDamage = 250; break;
				case 1: Attributes.WeaponDamage = 350; break;
				case 2: Attributes.WeaponDamage = 450; break;		
			}
		}
		public override void GetDamageTypes( Mobile wielder, out int phys, out int fire, out int cold, out int pois, out int nrgy )
		{
			phys = fire = pois = nrgy = 0;
			cold = 1000;
		}

		public HolyStaff( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
