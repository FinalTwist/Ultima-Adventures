using System;
using Server;
using Server.Misc;
using Server.Items;

namespace Server.Mobiles 
{ 
	[CorpseName( "an Holy Black Knight corpse" )] 
	public class HolyBlackKnight : BaseCreature 
	{ 
		[Constructable] 
		public HolyBlackKnight() : base( AIType.AI_Mage, FightMode.Evil, 10, 1, 0.2, 0.4 )
		{ 
			
			Name = "The Holy Black Knight";
			Body = 400;
			Hue = 1153;  

			SetStr( 6000, 6500 );
			SetDex( 1500, 2000 );
			SetInt( 35000, 40000 );

			SetHits( 200000, 250000 );

			SetDamage( 100, 150 );

			SetDamageType( ResistanceType.Physical, 100 );

			SetResistance( ResistanceType.Physical, 0, 1 );
			SetResistance( ResistanceType.Fire, 0, 1 );
			SetResistance( ResistanceType.Poison, 0, 1 );
			SetResistance( ResistanceType.Energy, 0, 1 );

			SetSkill( SkillName.EvalInt, 85.0, 900.0 );
			SetSkill( SkillName.Tactics, 75.1, 1100.0 );
			SetSkill( SkillName.MagicResist, 75.0, 497.5 );
			SetSkill( SkillName.Wrestling, 100.2, 1105.0 );
			SetSkill( SkillName.Meditation, 820.0);
			SetSkill( SkillName.Focus, 420.0);
			SetSkill( SkillName.Swords, 110.0, 1120.0 );

			Fame = 250000;
			Karma = 250000;

			Tamable = true;
			ControlSlots = 1;
			MinTameSkill = 119.5;

			VirtualArmor = 350;


			Item hair = new Item( Utility.RandomList( 0x203B, 0x2049, 0x2048, 0x204A ) );
			
				hair.Hue = 1150;
				hair.Layer = Layer.Hair;
				hair.Movable = false;
				AddItem( hair );
            
			TheBreastplateOfTheBlackKnight Chest = new TheBreastplateOfTheBlackKnight();
			Chest.Movable = false;
			AddItem(Chest);
			
			TheArmsOfTheBlackKnight Arms = new TheArmsOfTheBlackKnight();
			Arms.Movable = false;
			AddItem(Arms);
			
			TheLegsOfTheBlackKnight Legs = new TheLegsOfTheBlackKnight();
			Legs.Movable = false;
			AddItem(Legs);
			
			TheGlovesOfTheBlackKnight Gloves = new TheGlovesOfTheBlackKnight();
			Gloves.Movable = false;
			AddItem(Gloves);
			
			TheGorgetOfTheBlackKnight Gorget = new TheGorgetOfTheBlackKnight();
			Gorget.Movable = false;
			AddItem(Gorget);
			
			TheHelmOfTheBlackKnight Helm = new TheHelmOfTheBlackKnight();
			Helm.Movable = false;
			AddItem(Helm);
			
			TheEarringsOfTheBlackKnight Earrings = new TheEarringsOfTheBlackKnight();
			Earrings.Movable = false;
			AddItem(Earrings);
			
			TheRingOfTheBlackKnight Ring = new TheRingOfTheBlackKnight();
			Ring.Movable = false;
			AddItem(Ring);
			
			TheBraceletOfTheBlackKnight Bracelet = new TheBraceletOfTheBlackKnight();
			Bracelet.Movable = false;
			AddItem(Bracelet);
			
			TheShieldOfTheBlackKnight Shield = new TheShieldOfTheBlackKnight();
			Shield.Movable = false;
			AddItem(Shield);
			
			TheBladeOfTheBlackKnight Sword = new TheBladeOfTheBlackKnight();
			Sword.Movable = false;
			AddItem(Sword);				
							
			TheRobeOfTheBlackKnight Robe = new TheRobeOfTheBlackKnight();
			Robe.Movable = false;
   			AddItem(Robe);
   			
			//Horse BlackKnightsWarHorse = new BlackKnightsWarHorse();
        	 	//horse.Hue = 1;
			//horse.Hits = 20000;
			//horse.Karma = 50000;
        		//BlackKnightsWarHorse.Rider = this;
        		new BlackKnightsWarHorse().Rider = this;
			
			}

		public override void GenerateLoot()
		{
			
			switch ( Utility.Random( 48 ))
			{
				case 0: PackItem( new Diamond() ); break;
				case 1: PackItem( new BlackKnightsRobe() ); break;
				case 2: PackItem( new BlackKnightsSword() ); break;
				case 3: PackItem( new BlackKnightsShield() ); break;
				case 4: PackItem( new BlackKnightsRing() ); break;
				case 5: PackItem( new BlackKnightsEarrings() ); break;
				case 6: PackItem( new BlackKnightsHelm() ); break;
				case 7: PackItem( new BlackKnightsGorget() ); break;
				case 8: PackItem( new BlackKnightsLegs() ); break;
				case 9: PackItem( new BlackKnightsGloves() ); break;
				case 10: PackItem( new BlackKnightsArms() ); break;
				case 11: PackItem( new BlackKnightsBreastplate() ); break;
				case 12: PackItem( new BlackKnightsBracelet() ); break;
				{	
			
			}
		 }}
		
		public HolyBlackKnight( Serial serial ) : base( serial )
		{
		}
        public override bool AlwaysMurderer{ get{ return false; } }
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
