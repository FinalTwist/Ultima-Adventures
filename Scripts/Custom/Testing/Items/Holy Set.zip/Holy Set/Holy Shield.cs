using System;
using Server;

namespace Server.Items
{
	public class HolyShield : HeaterShield
	{
		public override int ArtifactRarity{ get{ return 666; } }

		public override int InitMinHits{ get{ return 666; } }
		public override int InitMaxHits{ get{ return 666; } }

		[Constructable]
		public HolyShield()
		{
			Hue = 1153;
			ArmorAttributes.SelfRepair = 50;
			
			Attributes.CastSpeed = 20;
			Attributes.CastRecovery = 20;
			Attributes.NightSight = 99;
			Attributes.ReflectPhysical = 15;
			Attributes.DefendChance = 15;
		}

		public HolyShield( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}
		
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}