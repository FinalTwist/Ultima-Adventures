using System;
using Server;
using Server.Items;


namespace Server.Items
{
	public class Fruitcake : Food
	{
		public override int LabelNumber{ get{ return 1041422; } }
		
		[Constructable]
		public Fruitcake() : this( null )
		{
		}
		
		[Constructable]
		public Fruitcake( String name ) : base ( 0x1044 )
		{
			Weight = 1.0;
		}
		
		public Fruitcake ( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			
			writer.Write( (int) 0); //Version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();
		}
		                  
	}
}

