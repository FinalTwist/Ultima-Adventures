using System;
using Server;
using Server.Items;
using System.Collections;
using Server.Multis;
using Server.Network;

namespace Server.Items
{
	public class Bones : Bag
	{
		public override int MaxWeight{ get{ return 0;} }
		public override int DefaultDropSound{ get{ return 0x42; } }
		
		[Constructable]
		public Bones()
		{
			Name = "a set of bones";
			Movable = true;
			GumpID = 9;
			ItemID = Utility.RandomList(3786, 3787, 3788, 3789, 3790, 3791, 3792, 3793, 3794);
		}
		
		public Bones( Serial serial ) : base ( serial )
		{
		}
		
                public override void Serialize( GenericWriter writer ) 
                { 
                        base.Serialize( writer ); 

                        writer.Write( (int) 0 ); // version 
                } 
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();			
		}
	}
}
