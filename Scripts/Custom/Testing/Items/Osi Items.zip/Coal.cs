using System;
using Server;
using Server.Items;


namespace Server.Items
{
	public class Coal : Item
	{
                public override int LabelNumber{ get{ return 1041426; } } // coal

		[Constructable]
		public Coal() : base( 0x19B9 )
		{
            Hue = 0x497;
			Weight = 12.0;
			Stackable = false;
			LootType = LootType.Blessed;
		}

		public Coal( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
