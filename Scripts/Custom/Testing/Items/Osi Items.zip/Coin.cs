using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class Coin : Item
	{
		public override int LabelNumber{ get{ return 1041301; } }
		
		[Constructable]
		public Coin() : this( null )
		{
		}
		
		[Constructable]
		public Coin( String name ) : base( 0x186E )
		{
			Weight = 1.0;
			LootType = LootType.Blessed;
		}
		
		public override void OnDoubleClick( Mobile from )
		{
            if ( !IsChildOf( from.Backpack ) )
            {
				from.SendLocalizedMessage( 1042001 );
			}
            else
			{
			   switch ( Utility.Random( 2 ) )
			{
			       case 0: SendLocalizedMessageTo( from, 1020002 ); break;
					
			       case 1: SendLocalizedMessageTo( from, 1010041 ); break;
			}
          }
		}
			
		public Coin( Serial serial ) : base( serial )
		{
		}
			
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
				
			writer.Write( (int) 0); //Version
		}
			
		public override  void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
				
			int version = reader.ReadInt();
		}
	}
}
