using System;
using Server;
using Server.Items;


namespace Server.Items
{
	public class GreetingCard : Item
	{
		public override int LabelNumber{ get{ return 1041425; } } //Seasons Greetings 
		
		[Constructable]
		public GreetingCard() : this( null )
		{
		}
		
		[Constructable]
		public GreetingCard( String name ) : base( 0x14EF )
		{
			Weight = 1.0;
			Hue = Utility.RandomList( 0x4EC, 0x27C, 0x671); //0x3C1
			LootType = LootType.Blessed;
		}
		
		public GreetingCard( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			
			writer.Write( (int) 0); //Version
		}
		
 		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();
		}
	}
}
