using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class Mondainplate : Item
	{
		public override int LabelNumber{ get{ return 1041244; } }
		
		[Constructable]
		public Mondainplate( ) : base( 0x9D7 )
		{
			Weight = 1.0;
		}
		
		public Mondainplate( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			
			writer.Write( (int) 0); //Version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();
			
		}
	}
}
