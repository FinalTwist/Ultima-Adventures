using System;
using Server;
using Server.Items;


namespace Server.Items
{
	public class NaughtyCard : Item
	{
		public override int LabelNumber{ get{ return 1041428; } } //Maybe next year you will get a nicer gift. 
		
		[Constructable]
		public NaughtyCard() : base( 0x14EF )
		{
			Weight = 1.0;
			Hue = Utility.RandomList( 0x4EC, 0x27C, 0x671); 
			LootType = LootType.Blessed;
		}
		
		public NaughtyCard( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			
			writer.Write( (int) 0); //Version
		}
		
 		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();
		}
	}
}
