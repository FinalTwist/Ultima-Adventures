using System;
using Server;
using Server.Items;


namespace Server.Items
{
        
	public abstract class BaseWristwatch : BaseJewel
	{
		
		public BaseWristwatch( int itemID ) : base( itemID, Layer.Bracelet )
		{
		}

		public BaseWristwatch( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Wristwatch : BaseWristwatch
	{
        public override int LabelNumber{ get{ return 1041421; } }

		[Constructable]
		public Wristwatch() : base( 0x1086 )
		{
			Weight = 1.0;
			LootType = LootType.Blessed;
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			int genericNumber;
			string exactTime;

			Clock.GetTime( from, out genericNumber, out exactTime );

			SendLocalizedMessageTo( from, genericNumber );
			SendLocalizedMessageTo( from, 1042958, exactTime ); // ~1_TIME~ to be exact
		}

		public Wristwatch( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
 }
