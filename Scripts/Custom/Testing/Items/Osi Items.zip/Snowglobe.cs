using System;
using Server;
using Server.Items;


namespace Server.Items
{
	public class SnowGlobe : Item
	{
		public override int LabelNumber{ get{ return Utility.RandomList( 1041454,  1041455, 1041456, 1041457, 1041458, 1041459, 1041460, 1041466, 1041461, 1041462, 1041463, 1041464, 1041465, 1041467, 1041468, 1041469, 1041470, 1041471, 1041472); } }
		
		[Constructable]
		public SnowGlobe () : this( null )
		{
		}
		
		[Constructable]
		public SnowGlobe ( String name ) : base( 0xE2E )
		{
			Name = name;
			Weight = 10.0;
			LootType = LootType.Blessed;
		}
		
		public SnowGlobe ( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			
			writer.Write( (int) 0); //Version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();
			
		}
	}
}
