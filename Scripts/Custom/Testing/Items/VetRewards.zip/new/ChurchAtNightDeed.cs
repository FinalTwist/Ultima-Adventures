using Server.Engines.VeteranRewards;

namespace Server.Items
{
	public class ChurchAtNightDeed : MiniHouseDeed, IRewardItem
	{
		private bool m_IsRewardItem;

		[CommandProperty( AccessLevel.GameMaster )]
		public bool IsRewardItem
		{
			get { return m_IsRewardItem; }
			set { m_IsRewardItem = value; }
		}

		public override BaseAddon Addon
		{
			get
			{
				VetMiniHouseAddon addon = new VetMiniHouseAddon( Type );
				addon.IsRewardItem = IsRewardItem;
				return addon;
			}
		}

		[Constructable]
        public ChurchAtNightDeed() : base( MiniHouseType.ChurchAtNight )
		{
			LootType = LootType.Blessed;
        }

        public ChurchAtNightDeed(Serial serial) : base(serial)
        {
        }

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.WriteEncodedInt( (int)0 ); // version

			writer.Write( m_IsRewardItem );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadEncodedInt();

			m_IsRewardItem = reader.ReadBool();
		}
	}
}