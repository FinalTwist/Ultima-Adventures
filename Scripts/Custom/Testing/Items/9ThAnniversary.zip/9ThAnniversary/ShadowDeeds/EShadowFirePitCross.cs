using System;
using Server;
using Server.Items;
using Server.Network;

namespace Server.Items
{
    public class EShadowFirePitCrossComponent : AddonComponent
    {
        [Constructable]
        public EShadowFirePitCrossComponent(int itemID)
            : base(itemID)
        {
            Weight = 100.0;
            Movable = false;
        }

        public override int LabelNumber { get { return 1076680; } }
        public EShadowFirePitCrossComponent(Serial serial)
            : base(serial)
        {
        }

        public override void OnDoubleClick(Mobile from)
        {
            if (!from.InRange(this.GetWorldLocation(), 2))
            {
                from.LocalOverheadMessage(MessageType.Regular, 906, 1019045); // I can't reach that.
            }
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }

    public class EShadowFirePitCrossAddon : BaseAddon
    {
        public override BaseAddonDeed Deed { get { return new EShadowFirePitCrossDeed(); } }

        [Constructable]
        public EShadowFirePitCrossAddon()
        {
            AddComponent(new EShadowFirePitCrossComponent(0x3651), 1, 0, 0);
            AddComponent(new EShadowFirePitCrossComponent(0x3652), 0, 0, 0);
            AddComponent(new EShadowFirePitCrossComponent(0x3653), 1, -1, 0);
        }

        public EShadowFirePitCrossAddon(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }

    public class EShadowFirePitCrossDeed : BaseAddonDeed
    {
        public override BaseAddon Addon { get { return new EShadowFirePitCrossAddon(); } }
        public override int LabelNumber { get { return 1076680; } }

        [Constructable]
        public EShadowFirePitCrossDeed()
        {
            ItemID = 0x14EF;
            Hue = 0x774;
            Weight = 1.0;
            LootType = LootType.Blessed;
        }

        public EShadowFirePitCrossDeed(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}