using System;
using System.Collections;
using Server.Multis;
using Server.Mobiles;
using Server.Network;
using System.Collections.Generic;
using Server.ContextMenus;

namespace Server.Items
{
    [Furniture]
    [FlipableAttribute(0x9AA, 0xE7D)]
    public class CrystalGiftBoxOfGifts : Ninth_anniversary_crystal_gift_box
    {
        [Constructable]
        public CrystalGiftBoxOfGifts()
            : this(1)
        {
        }

        [Constructable]
        public CrystalGiftBoxOfGifts(int amount)
        {
            DropItem(new ninth_anniversary_coin());
            switch (Utility.Random(8))
            {
                case 0: DropItem(new ECrystalAltarDeed()); break;
                case 1: DropItem(new ECrystalTableDeed()); break;
                case 2: DropItem(new ECrystalSupplicantStatueDeed()); break;
                case 3: DropItem(new ECrystalRunnerStatueDeed()); break;
                case 4: DropItem(new ECrystalBullDeed()); break;
                case 5: DropItem(new ECrystalBrazierDeed()); break;
                case 6: DropItem(new ECrystalBeggarStatueDeed()); break;
                case 7: DropItem(new ECrystalThroneDeed()); break;
            }

        }

        public CrystalGiftBoxOfGifts(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version 
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }


    [Furniture]
    [Flipable(0x9AA, 0xE7D)]
    public class Ninth_anniversary_crystal_gift_box : LockableContainer
    {
        public override int LabelNumber { get { return 1076788; } }

        [Constructable]
        public Ninth_anniversary_crystal_gift_box()
            : base(0xE7D)
        {
            Weight = 4.0;
            Hue = 0x495;
        }

        public Ninth_anniversary_crystal_gift_box(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}