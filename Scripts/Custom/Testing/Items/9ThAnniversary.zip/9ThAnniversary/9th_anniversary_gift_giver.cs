using System;
using Server;
using Server.Items;

namespace Server.Misc
{
    public class OSI_9thAnniversary : GiftGiver
    {
        public static void Initialize()
        {
            GiftGiving.Register(new OSI_9thAnniversary());
        }

        public override DateTime Start { get { return new DateTime(2006, 12, 07); } }
        public override DateTime Finish { get { return new DateTime(2006, 12, 30); } }

        public override void GiveGift(Mobile mob)
        {
            Bag bag = new Bag();

            bag.DropItem(new CrystalGiftBoxOfGifts());
            bag.DropItem(new CrystalGiftBoxOfGifts());
            bag.DropItem(new CrystalGiftBoxOfGifts());
            bag.DropItem(new BlackGiftBoxOfGifts());
            bag.DropItem(new BlackGiftBoxOfGifts());
            bag.DropItem(new BlackGiftBoxOfGifts());

            switch (GiveGift(mob, bag))
            {
                case GiftResult.Backpack:
                    mob.SendLocalizedMessage(1076789);
                    break;
                case GiftResult.BankBox:
                    mob.SendLocalizedMessage(1076787);
                    break;
            }
        }
    }
}