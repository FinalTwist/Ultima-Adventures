using System;
using System.Collections;
using Server.Multis;
using Server.Mobiles;
using Server.Network;
using System.Collections.Generic;
using Server.ContextMenus;

namespace Server.Items
{
    [Furniture]
    [FlipableAttribute(0x9AA, 0xE7D)]
    public class BlackGiftBoxOfGifts : Ninth_anniversary_black_gift_box
    {
        [Constructable]
        public BlackGiftBoxOfGifts()
            : this(1)
        {
        }

        [Constructable]
        public BlackGiftBoxOfGifts(int amount)
        {
            DropItem(new ninth_anniversary_coin());
            switch (Utility.Random(11))
            {
                case 0: DropItem(new EGlobeOfSosariaDeed()); break;
                case 1: DropItem(new EObsidianPillarDeed()); break;
                case 2: DropItem(new EObsidianRockDeed()); break;
                case 3: DropItem(new EShadowBannerDeed()); break;
                case 4: DropItem(new EShadowAltarDeed()); break;
                case 5: DropItem(new ESpikePostSouthDeed()); break;
                case 6: DropItem(new ESpikePostEastDeed()); break;
                case 7: DropItem(new ESpikeColumnDeed()); break;
                case 8: DropItem(new EShadowPillarDeed()); break;
                case 9: DropItem(new EShadowFirePitCrossDeed()); break;
                case 10: DropItem(new EShadowFirePitDeed()); break;
            }

        }

        public BlackGiftBoxOfGifts(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version 
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }


    [Furniture]
    [Flipable(0x9AA, 0xE7D)]
    public class Ninth_anniversary_black_gift_box : LockableContainer
    {
        public override int LabelNumber { get { return 1076788; } }

        [Constructable]
        public Ninth_anniversary_black_gift_box()
            : base(0xE7D)
        {
            Weight = 4.0;
            Hue = 0x774;
        }

        public Ninth_anniversary_black_gift_box(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}