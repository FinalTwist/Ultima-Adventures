using System;
using Server;
using Server.Items;

namespace Server.Items
{
    public class ninth_anniversary_coin : Item
    {
        public override int LabelNumber { get { return 1076790; } }

        [Constructable]
        public ninth_anniversary_coin()
            : this(null)
        {
        }

        [Constructable]
        public ninth_anniversary_coin(String name)
            : base(0x3198)
        {
            Hue = 0xF2;
            Stackable = false;
            Weight = 1.0;
            LootType = LootType.Blessed;
        }

        public override void OnDoubleClick(Mobile from)
        {
            //if (!IsChildOf(from.Backpack))
            //{
            //    from.SendLocalizedMessage(1042001);
            //}
            //else
            {
                switch (Utility.Random(2))
                {
                    case 0: SendLocalizedMessageTo(from, 1020002); break;

                    case 1: SendLocalizedMessageTo(from, 1010041); break;
                }
            }
        }

        public ninth_anniversary_coin(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); //Version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}