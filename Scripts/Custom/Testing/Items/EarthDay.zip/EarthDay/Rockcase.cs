using System;
using Server.Items;
using Server.Network;

namespace Server.Items
{
	public class Rockcase : Item
	{
		[Constructable]
		public Rockcase() : base( 0x2FEA )
		{
            Name = "Rock Display Case";
			Weight = 2.0;
			LootType = LootType.Blessed;
		}

        public Rockcase(Serial serial) : base(serial)
		{
		}
        public override void GetProperties(ObjectPropertyList list)
        {
            base.GetProperties(list);

            list.Add(1060662, "Happy Earth Day\t2008");
        }

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}