using System;
using Server;
using Server.Items;

namespace Server.Misc
{
    public class EarthDay : GiftGiver
	{
		public static void Initialize()
		{
			GiftGiving.Register( new EarthDay() );
		}

		public override DateTime Start{ get{ return new DateTime( 2008, 4, 22 ); } }
		public override DateTime Finish{ get{ return new DateTime( 2008, 4, 30 ); } }

		public override void GiveGift( Mobile mob )
		{
            EarthDayBag bag = new EarthDayBag();
		

			bag.DropItem( new Flowertree() );
            bag.DropItem( new Rockcase());
            bag.DropItem( new Anemone());
            bag.DropItem( new Earthglobe());


			


			switch ( GiveGift( mob, bag ) )
			{
				case GiftResult.Backpack:
                    mob.SendMessage(0x482, "Happy Earth Day from the team!  Gift items have been placed in your backpack.");
					break;
				case GiftResult.BankBox:
                    mob.SendMessage(0x482, "Happy Earth Day from the team!  Gift items have been placed in your bank box.");
					break;
			}
		}
	}
}