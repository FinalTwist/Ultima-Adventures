using System;
using Server.Network;
using Server.Gumps;
using Server.Multis;
using System.Collections;
using System.Collections.Generic;
using Server.ContextMenus;
using Server.Engines.XmlSpawner2;

namespace Server.Items
{
    public enum HolidayType
    {
        Christmas,
    }

    public class HolidayGiftStone : Item
    {
        private bool m_Active;
        private string m_HolidayName = null;
        private HolidayType m_Type;
        private TimeSpan m_MinAge;
        private int m_Gifts;

        [CommandProperty(AccessLevel.GameMaster)]
        public bool Active
        {
            get { return m_Active; }
            set { m_Active = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public string HolidayName
        {
            get { return m_HolidayName; }
            set { m_HolidayName = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public HolidayType Type
        {
            get { return m_Type; }
            set { m_Type = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public TimeSpan MinAge
        {
            get { return m_MinAge; }
            set { m_MinAge = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public int Gifts
        {
            get { return m_Gifts; }
            set { m_Gifts = value; }
        }

        [Constructable]
        public HolidayGiftStone(string holName)
        {
            ItemID = 0x0EDD;
            Movable = false;
            Name = "A Holiday Stone";

            m_HolidayName = holName;
            Movable = false;
        }

        public HolidayGiftStone(Serial serial)
            : base(serial)
        {
        }

        public override void OnDoubleClick(Mobile from)
        {
            DateTime now = DateTime.Now;
            bool takenGift = false;

    		ArrayList list = XmlAttach.FindAttachments(from,typeof(XmlDate));
			if(list != null || list.Count > 0)
			{
				foreach(XmlDate x in list)
				{
					if(x.Name == m_HolidayName && x.Date.Year == now.Year)
                    {
                        takenGift = true;
                    }
				}
			}

            if (!from.InRange(GetWorldLocation(), 1))
                from.LocalOverheadMessage(MessageType.Regular, 0x3B2, 1019045); // I can't reach that.
            else if (!m_Active)
            {
                from.SendMessage("Gifts are not being given out for this holiday at the moment.");
            }
            else if (from.CreationTime > (now - m_MinAge))
            {
                from.SendMessage("You are not old enough to recieve gift.");
            }
            else if (takenGift)
            {
                from.SendMessage("You have already recieved your gift for this year.");
            }
            else
            {
                from.AddToBackpack(new HolidayGiftBox(m_Type, m_Gifts));
                from.SendMessage("Happy {0}! Enjoy your gift.", m_HolidayName);
                XmlAttach.AttachTo(from, new XmlDate(m_HolidayName));
            }
        }

        public override bool ForceShowProperties { get { return true; } }

        public override void GetProperties(ObjectPropertyList list)
        {
            base.GetProperties(list);

            list.Add(m_HolidayName);
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version

            writer.Write((bool)m_Active);
            writer.Write((string)m_HolidayName);
            writer.Write((int)m_Type);
            writer.Write(m_MinAge);
            writer.Write((int)m_Gifts);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();

            m_Active = reader.ReadBool();
            m_HolidayName = reader.ReadString();
            m_Type = (HolidayType)reader.ReadInt();
            m_MinAge = reader.ReadTimeSpan();
            m_Gifts = reader.ReadInt();
        }
    }
}