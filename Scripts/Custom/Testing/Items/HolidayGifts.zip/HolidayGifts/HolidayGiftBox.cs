using System;
using Server.Items;
using Server.Network;

namespace Server.Items
{
    [Furniture]
    public class HolidayGiftBox : GiftBox
    {
        private HolidayType m_Type;
        private int m_HolidayYear;
        private int m_Gifts;

        [CommandProperty(AccessLevel.GameMaster)]
        public HolidayType Type
        {
            get { return m_Type; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public int HolidayYear
        {
            get { return m_HolidayYear; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public int Gifts
        {
            get { return m_Gifts; }
        }

        private void XmasGifts(Container box, int gifts)
        {
            for (int i = 0; i < gifts; i++)
            {
                box.DropItem(new XmasDeed(m_HolidayYear));

                switch (Utility.Random(2))
                {
                    case 0:
                        box.DropItem(new CandyCane());
                        box.DropItem(new CandyCane());
                        break;
                    case 1:
                        box.DropItem(new GingerBreadCookie());
                        box.DropItem(new GingerBreadCookie());
                        break;
                }
            }
        }

        [Constructable]
        public HolidayGiftBox(HolidayType type, int gifts)
        {
            ItemID = 0x232A;

            m_Type = type;
            m_HolidayYear = DateTime.Now.Year;
            m_Gifts = gifts;

            Weight = 2.0;
            Hue = Utility.RandomDyedHue();

            switch (Type)
            {
                case HolidayType.Christmas: XmasGifts(this, m_Gifts); break;
            }
        }

        public HolidayGiftBox(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version

            writer.Write((int)m_Type);
            writer.Write((int)m_HolidayYear);
            writer.Write((int)m_Gifts);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();

            m_Type = (HolidayType)reader.ReadInt();
            m_HolidayYear = reader.ReadInt();
            m_Gifts = reader.ReadInt();
        }
    }
}