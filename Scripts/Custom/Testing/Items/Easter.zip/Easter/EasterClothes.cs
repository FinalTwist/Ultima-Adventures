﻿using System;
using Server;

namespace Server.Items
{


	public class EasterDress : PlainDress
	{
		[Constructable]
		public EasterDress()
		{
			Hue = Utility.RandomList( 263, 53, 88 );
			Name = "easter dress";
			LootType = LootType.Blessed;
			
		}
		
		public override bool Dye( Mobile from, DyeTub sender )
		{
		from.SendLocalizedMessage( 1042083 ); // You can not dye that.
		return false;
		}

		public EasterDress( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}
		
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class EasterHat : FloppyHat
	{
		[Constructable]
		public EasterHat()
		{
			Hue = Utility.RandomList( 263, 53, 88 );
			Name = "easter hat";
			LootType = LootType.Blessed;
		}
		
		public override bool Dye( Mobile from, DyeTub sender )
		{
		from.SendLocalizedMessage( 1042083 ); // You can not dye that.
		return false;
		}

		public EasterHat( Serial serial ) : base( serial )
		{
		}


		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}
		
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}