﻿using System;
using Server;

namespace Server.Items
{
	public class MarshmallowPeep : Food
	{
		[Constructable]
		public MarshmallowPeep() : base( 0x211A )
		{
			Hue = 53;
			Name = "a marshmallow peep";
			//LootType = LootType.Blessed;
		}

		public MarshmallowPeep( Serial serial ) : base( serial )
		{
		}


		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}
		
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
