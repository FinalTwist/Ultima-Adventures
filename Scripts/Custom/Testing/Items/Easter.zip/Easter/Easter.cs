﻿using System;
using Server;
using Server.Items;

namespace Server.Misc
{
	public class Easter : GiftGiver
	{
		public static void Initialize()
		{
			GiftGiving.Register( new Easter() );
		}

		public override DateTime Start{ get{ return new DateTime( 2013, 3, 29 ); } }
		public override DateTime Finish{ get{ return new DateTime( 2013, 3, 31 ); } }

		public override void GiveGift( Mobile mob )
		{
			Basket box = new Basket();
			box.Hue = 263;
			box.Name = "Easter 2013";
			
			box.DropItem( new EasterEggs() );
			box.DropItem( new EasterGrass() );
            box.DropItem( new ChocolateBunny () );
		    box.DropItem( new MarshmallowPeep () );
		   

			
			 int random = Utility.Random( 100 );

			 if ( random < 50 )
				box.DropItem( new EasterDress() );
			else
				box.DropItem( new EasterHat() );

			switch ( GiveGift( mob, box ) )
			{
				case GiftResult.Backpack:
					mob.SendMessage( 0x482, "Happy Easter!  Gift items have been placed in your backpack." );
					break;
				case GiftResult.BankBox:
					mob.SendMessage( 0x482, "Happy Easter!  Gift items have been placed in your bank box." );
					break;
			}
		}
	}
}
