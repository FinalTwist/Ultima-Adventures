using System;
using Server;
using Server.Items;

namespace Server.Items
{
    public class EasterGrass : Item
    {
        [Constructable]
        public EasterGrass(): base (0x0C5F)
        {
            Name = "Easter Grass";
            Weight = 1.0;
            Hue = 3 + (Utility.Random(20) * 5);
            
        }
        public EasterGrass( Serial serial ) : base( serial )
		{
		}
         
        /*public override Item Dupe(int amount)
        {
            return base.Dupe(new EasterGrass(), amount);
        } */

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}